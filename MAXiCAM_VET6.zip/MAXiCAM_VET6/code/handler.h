#ifndef __HANDLER_H
#define __HANDLER_H

#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"
#include "stdint.h"
#include "string.h"

extern uint8_t re_buff;
extern char send_buff[20];

void uart_handler(void);

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);

#endif



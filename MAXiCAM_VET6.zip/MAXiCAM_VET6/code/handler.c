#include "handler.h"

uint8_t uart_flag;
uint8_t re_buff;
char send_buff[20];

void uart_handler(void)
{
	if(uart_flag == 1)
	{
		if(re_buff == 1)
		{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);		
		sprintf(send_buff, "LED11\r\n");
		HAL_UART_Transmit(&huart3, (uint8_t *)send_buff,strlen(send_buff), 50);
		}
		else if(re_buff == 2)
		{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
		sprintf(send_buff, "LED22\r\n");
		HAL_UART_Transmit(&huart3, (uint8_t *)send_buff,strlen(send_buff), 50);		
		}
	re_buff = 0;			
	uart_flag = 0;
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART3)
	{
	uart_flag = 1;
		
	HAL_UART_Receive_IT(&huart3, &re_buff, sizeof(re_buff));	
	}
}

